<?php 
require_once('../../private/initialize.php'); 

$pageTitle = "Delete";
include (SHARED_PATH . '/salamander-header.php');
?>

<h1>Stub for Delete Salamander</h1>

<a href="<?= url_for('/salamanders/index.php'); ?>">&laquo; Back to Salamander List</a>

<?php include(SHARED_PATH . '/salamander-footer.php'); ?>