<footer>
  <p>&copy; <?= date('Y'); ?> Southern Appalachian Salamanders</p>
</footer>

</body>
</html>

<?php db_disconnect($db); ?>