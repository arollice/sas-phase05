<?php

define("DB_SERVER", "localhost");
define("DB_USER", "arollice_sally");
define("DB_PASS", "P@ssWord4321");
define("DB_NAME", "arollice_salamanders");

?>