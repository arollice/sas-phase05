<footer>
 &copy; <?php echo date('Y'); ?> Southern Appalachian Salamanders
 
</footer>

</body>
</html>
  
<?php db_disconnect($db); ?>
