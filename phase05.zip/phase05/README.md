# Salamander README

In order for this program to work you will need to fill out the **private/credentials.php** file with your database credentials.

You will also need to download the **salamanders.sql** file and run the code to create the database. I have purposely left out the user creation.