<?php
// local
define("DB_SERVER", "localhost");
define("DB_USER", "arollice_sally");
define("DB_PASS", "P@ssWord4321");
define("DB_NAME", "arollice_salamanders");

//a2
// define("DB_SERVER", "localhost");
// define("DB_USER", "charli12_doall");
// define("DB_PASS", "ErYje7HV2o2Lqp7B9gx");
// define("DB_NAME", "charli12_salamanders");
